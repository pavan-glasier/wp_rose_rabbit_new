jQuery( document ).ready(function() {
	//console.log( "admin js ready!" );

	jQuery(function(){
		jQuery('.color_field').wpColorPicker();
	})
});