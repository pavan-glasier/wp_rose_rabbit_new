<?php
// Silence is Golden