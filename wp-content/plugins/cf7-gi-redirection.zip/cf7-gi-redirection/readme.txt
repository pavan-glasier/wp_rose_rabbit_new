Contact Form 7 - Redirection on Thank You page
==============================================

Description
-----------

After form submitting redirect the form to thank you page or 
another as you choose in setting of this plugin.

you can put url or select a page as your requirements what you want.