<?php return
    array( 'dependencies' =>
        array(
            'wp-blocks',
            'wp-element',
            'wp-block-editor',
            'wp-polyfill'
        ),
        'version' => '0.1'
    );